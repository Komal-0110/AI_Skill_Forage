import React, { useState } from 'react'

const LoginModal = ({loginModalOpen, setLoginModalOpen}) => {

    const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [input, setInput] = useState('');
  return (
    <form>
        <p>Use login model</p>
    </form>
  )
}

export default LoginModal
